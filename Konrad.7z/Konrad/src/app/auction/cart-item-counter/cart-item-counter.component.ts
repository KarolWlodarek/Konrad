import { Component, OnInit, Input } from '@angular/core';
import { CartService } from '../cart.service';

@Component({
  selector: 'ap-cart-item-counter',
  template: `
    <p>
      Ilość w koszyku [{{cartService.countItems() | async }}]
    </p>
  `,
  styles: []
})
export class CartItemCounterComponent implements OnInit {

  constructor(public cartService: CartService) { }

  ngOnInit() {
  }

}
