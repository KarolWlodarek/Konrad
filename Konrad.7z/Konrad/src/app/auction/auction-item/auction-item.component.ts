import {Component, Input, OnInit} from '@angular/core';
import { AuctionItem } from '../auction-item';
import { CartService } from '../cart.service';

@Component({
  selector: 'ap-auction-item',
  template: `
    <div class="card">
      <div apHighlight class="card-header">{{auction.title}} {{auction.id}}</div>
      <img class="card-img" [src]="auction.imgUrl">
      <div class="card-body">
        <p class="card-text">
          {{auction.description}}
        </p>
        <button class="btn btn-primary" (click)="handleAddToCart(auction)" >
          <i class="fa fa-cart-plus"></i>
        </button>
      </div>
    </div>
  `,
  styles: []
})
export class AuctionItemComponent implements OnInit {

  @Input() auction: AuctionItem;
  constructor(private cartService: CartService) { }

  ngOnInit() {
  }

  handleAddToCart(auction) {
    this.cartService.addToCart(auction);
  }
}
