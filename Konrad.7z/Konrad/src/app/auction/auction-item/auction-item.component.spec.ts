import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { AuctionItemComponent } from './auction-item.component';

describe('AuctionItemComponent', () => {
  let component: AuctionItemComponent;
  let fixture: ComponentFixture<AuctionItemComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ AuctionItemComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(AuctionItemComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
