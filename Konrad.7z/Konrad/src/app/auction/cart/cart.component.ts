import { Component, OnInit } from '@angular/core';
import { CartService } from '../cart.service';
import { AuctionItem } from '../auction-item';

@Component({
  selector: 'ap-cart',
  templateUrl: './cart.component.html',
  styles: []
})
export class CartComponent implements OnInit {
  services: AuctionItem[];
  constructor(private cartService: CartService) { }

  ngOnInit() {
    this.cartService.getAll().subscribe(x => {
      this.services = x.map(y => y);
    });
  }

}
