import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'ap-add-auction',
  templateUrl: './add-auction.component.html',
  styles: []
})
export class AddAuctionComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
