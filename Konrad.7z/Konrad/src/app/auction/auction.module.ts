import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AuctionsComponent } from './auctions/auctions.component';
import { PromotionsComponent } from './promotions/promotions.component';
import { AuctionRoutingModule } from './auction-routing.module';
import { AuctionItemComponent } from './auction-item/auction-item.component';
import { SharedModule } from '../shared/shared.module';
import { AuctionFilterPipe } from './auction-filter.pipe';
import { AddAuctionComponent } from './add-auction/add-auction.component';
import { CartComponent } from './cart/cart.component';
import { CartItemCounterComponent } from './cart-item-counter/cart-item-counter.component';


@NgModule({
  declarations: [
    AuctionsComponent,
    PromotionsComponent,
    AuctionItemComponent,
    AuctionFilterPipe,
    AddAuctionComponent,
    CartComponent,
    CartItemCounterComponent
  ],
  imports: [
    CommonModule,
    AuctionRoutingModule,
    SharedModule
  ],
  exports: [
    AuctionsComponent,
    PromotionsComponent
  ]
})
export class AuctionModule { }
