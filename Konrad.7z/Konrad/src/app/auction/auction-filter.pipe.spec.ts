import { AuctionFilterPipe } from './auction-filter.pipe';

describe('AuctionFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new AuctionFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
