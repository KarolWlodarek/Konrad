import { Component, OnInit } from '@angular/core';
import {AuctionItem} from '../auction-item';
import {AuctionService} from '../auction.service';

@Component({
  selector: 'ap-auctions',
  templateUrl: './auctions.component.html',
  styleUrls: ['./auctions.component.css'],
  /*
  providers: [
    AuctionService
  ]
  */
})
export class AuctionsComponent implements OnInit {

  auctions: AuctionItem[] = [];

  /*
  private auctionService: AuctionService
  constructor(auctionService: AuctionService) {
    this.auctionService = auctionService;
  }
  */

  constructor(private auctionService: AuctionService) { }

  ngOnInit() {
    this.auctionService
      .getAll()
      .subscribe((auctions: AuctionItem[]) => {
        this.auctions = auctions;

      });
  }

}
