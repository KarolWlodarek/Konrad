import { Injectable } from '@angular/core';
import { AuctionItem } from './auction-item';
import { BehaviorSubject, Observable } from 'rxjs';
import { map } from 'rxjs/operators'

@Injectable({
  providedIn: 'root'
})
export class CartService {
  auctionsSubj = new BehaviorSubject<AuctionItem[]>([]);
  items$ = this.auctionsSubj.asObservable();

  constructor() { }

  addToCart(item: AuctionItem) {
    const auctions = this.auctionsSubj.getValue();
    this.auctionsSubj.next([...auctions, item]);
  }

  getAll(): Observable<AuctionItem[]> {
    return this.items$;
  }

  countItems(): Observable<number> {
    return this.items$.pipe(map((arr) => arr.length));
  }
}

