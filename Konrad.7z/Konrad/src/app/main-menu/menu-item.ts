export interface MenuItem {
  link: string;
  title: string;
}
