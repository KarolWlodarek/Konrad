import { Component, OnInit } from '@angular/core';

import {MenuItem} from './menu-item';

@Component({
  selector: 'ap-main-menu',
  templateUrl: './main-menu.component.html',
  styles: [
   `.new-navbar {
    display: flex !important;
    justify-content: space-between;
  }` 
    
    /*`
    nav {
      background-color: aqua;
    }
  `*/]
})
export class MainMenuComponent implements OnInit {

  isMenuShown = true;
  menuItems: MenuItem[] = [
    { link: 'auctions', title: 'Aukcje' },
    { link: 'promotions', title: 'Promocje' },
    { link: 'advices', title: 'Podpowiadamy' },
  ];

  constructor() { }

  ngOnInit() {
  }

  toggleMenu(/*ev: MouseEvent*/) {
    this.isMenuShown = !this.isMenuShown;
    /*console.log(ev);*/
  }

}
