import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'ap-advice-details',
  template: `
    <p>
      advice-details works {{activeAdviceId}}!
    </p>
  `,
  styles: []
})
export class AdviceDetailsComponent implements OnInit {
  activeAdviceId: number;
  constructor(private activatedRoute: ActivatedRoute) { }

  ngOnInit() {
    this.activatedRoute.params.subscribe((params) => {
      this.activeAdviceId = params.adviceId;
    });
  }

}
