import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AdviceRoutingModule } from './advice-routing.module';
import { AdviceComponent } from './advice/advice.component';
import { AdviceDetailsComponent } from './advice/advice-details/advice-details.component';


@NgModule({
  declarations: [AdviceComponent, AdviceDetailsComponent],
  imports: [
    CommonModule,
    AdviceRoutingModule
  ]
})
export class AdviceModule { }
