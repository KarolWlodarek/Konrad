import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AdviceComponent } from './advice/advice.component';
import { AdviceDetailsComponent } from './advice/advice-details/advice-details.component';

const routes: Routes = [
  {path: '', component: AdviceComponent, 
   children: [
     { path: ':adviceId', component: AdviceDetailsComponent },

   ]},
 
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AdviceRoutingModule { }
