import {Component, OnInit} from '@angular/core';

@Component({
  selector: 'ap-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {

  title = 'Auction Portal';
  showNumber = false;

  constructor() { }

  ngOnInit() {
  }

}
