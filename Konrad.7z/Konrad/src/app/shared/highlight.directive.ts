import {AfterViewInit, Directive, ElementRef, HostBinding, HostListener} from '@angular/core';

@Directive({
  selector: '[apHighlight]'
})
export class HighlightDirective implements AfterViewInit {

  @HostBinding('style.backgroundColor') bgColor: string;

  constructor(private el: ElementRef) {}

  ngAfterViewInit(): void {
    // console.log(this.el.nativeElement);
  }

  @HostListener('mouseover')
  mouseOver() {
    this.bgColor = 'yellow';
  }

  @HostListener('mouseout')
  mouseOut() {
    this.bgColor = '';
  }


}
