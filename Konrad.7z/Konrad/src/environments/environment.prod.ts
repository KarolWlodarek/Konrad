export const environment = {
  production: true,
  restURL: '/api',
};
